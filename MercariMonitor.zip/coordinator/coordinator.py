import json
import logging
import time
import datetime
import cache.cache
import web.telegram as telegram
from typing import List
from config import config
from scraper import searcher
from string import Template

logging.basicConfig(
    filename='error.log',  # 指定日志文件的名称
    format='%(asctime)s %(levelname)-8s %(message)s',
    level=logging.ERROR,
    datefmt='%Y-%m-%d %H:%M:%S')


def start(
        searches: List[config.Search],
        delay: int,
        msg_tpl: str,
        change_rate: float,
        telegram_client: telegram.TelegramClient,
):
    while True:
        # time_start = time.time()  # 记录开始时间
        cached_data = read_cache()

        scraped = {}
        for s in searches:
            kw: str = s['keywords']

            cached_ids_str = ''
            if kw in cached_data:
                cached_ids_str = cached_data[kw]


            cached_ids = cached_ids_str
            # cached_ids = cached_ids_str.split(cache.cache.last_ids_separator)

            items = handle_search(kw, cached_ids, change_rate)
            scraped[kw] = items
            # time.sleep(delay)

        send_to_telegram(scraped, msg_tpl, telegram_client)

        write_cache(scraped, cached_data)

        time.sleep(delay)

        # time_end = time.time()  # 记录结束时间
        # logging.info(f"时间差: {time_end - time_start:.2f} 秒")


def handle_search(kw: str, cached_ids: str, change_rate: float):
    # logging.info(f'Handling keywords {kw}...')
    res = []
    items = searcher.search(kw)

    for it in items:
        if it.id in cached_ids:
            if int(it.price) > int(cached_ids.get(it.id)):
                it.price_status = '涨价'
                cached_ids[it.id] = it.price
            elif int(it.price) < int(cached_ids.get(it.id)):
                it.price_status = '降价'
                cached_ids[it.id] = it.price
            else:
                # it.price_status = '上新'
                continue
        else:
            it.price_status = '上新'

        if change_rate > 0:
            it.price_currency = round(float(it.price) * change_rate, 2)

        res.append(it)

    if (len(res)>0):
        logging.info(f'Handling keywords {kw}...')
        logging.info(f'Found {len(res)} new items for keywords {kw}')

    return res


def write_cache(scraped, cached_data):
    logging.info('Writing cache...')
    to_persist = build_cache(scraped, cached_data)
    json.dump(to_persist, open('scraped.json', 'w'))

    logging.info('Cache written!')


def read_cache():
    try:
        res = json.load(open('scraped.json'))
    except Exception as e:
        logging.error(f'could not read cache {e.__class__}')
        return {}

    return res


def build_cache(scraped, cached_data):
    res = {}
    for kw in scraped:
        val = scraped[kw]
        item_data = {}  # 创建一个字典，用于存储商品ID和价格的键值对
        i = 0
        for item in val:
            item_data[item.id] = item.price  # 将商品ID作为键，价格作为值存储在字典中
            i += 1
            if i >= cache.cache.last_ids_size:
                break


        # 如果找到的新商品数量小于 last_ids_size，则从缓存中添加商品ID
        if len(item_data) < cache.cache.last_ids_size:
            if kw in cached_data:
                cached = cached_data[kw]
                # cached = cached_data[kw].split(cache.cache.last_ids_separator)
                for i in cached:
                    # 如果价格在缓存中不可用，可以将其设置为 None 或任何适当的占位符
                    item_data[i] = cached[i]
                    if len(item_data) >= cache.cache.last_ids_size:
                        break

        res[kw] = item_data  # 将字典存储为关键字的缓存数据

    return res


def send_to_telegram(scraped, msg_tpl: str, telegram_client: telegram.TelegramClient):
    logging.info('Sending messages to Telegram')

    for kw in scraped:
        for it in scraped[kw]:
            d = {
                'id': it.id,
                'imageURL': it.imageURL,
                'price': it.price,
                'productName': it.productName,
                'productURL': it.productURL,
                'soldOut': it.soldOut,
                'status': it.status,
                'updated': it.updated,
                'created': it.created,
                'priceStatus': it.price_status,
            }
            # 价格
            if hasattr(it, 'price_currency'):
                d['priceCurrency'] = it.price_currency
            else:
                d['priceCurrency'] = 0

            # 创建时间
            d['Created'] = datetime.datetime.fromtimestamp(int(it.created)).strftime("%Y-%m-%d %H:%M:%S")

            # 更新时间
            d['Updated'] = datetime.datetime.fromtimestamp(int(it.updated)).strftime("%Y-%m-%d %H:%M:%S")

            src = Template(msg_tpl)
            formatted = src.substitute(d)

            try:
                if telegram_client.download_photos:
                    telegram_client.bot.send_photo(telegram_client.chat_id, it.imageURL, formatted)
                else:
                    telegram_client.bot.send_message(telegram_client.chat_id, formatted)
            except Exception as e:
                logging.error(f'error while sending message to telegram, skipping: {e.__class__}')
                
    logging.info('Messages sent!')
