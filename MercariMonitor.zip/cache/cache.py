last_ids_size = 400
last_ids_separator = ','


class CachedIDs:
    url: str
    last_ids: str
