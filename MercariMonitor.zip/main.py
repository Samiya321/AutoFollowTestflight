import config.config as config
import web.telegram as telegram
from coordinator import coordinator as coordinator
# import os
import urllib3

# 禁用证书验证警告
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# 设置HTTP代理
# os.environ["http_proxy"] = "http://127.0.0.1:7890"
# os.environ["https_proxy"] = "http://127.0.0.1:7890"


print('Starting mercari-watchdog...')

cfg = config.load()

telegram_client = telegram.new_telegram_client(cfg.telegram_token, cfg.telegram_chat_id, cfg.download_photos)

coordinator.start(cfg.searches, cfg.delay, cfg.msg_tpl, cfg.change_rate, telegram_client)
